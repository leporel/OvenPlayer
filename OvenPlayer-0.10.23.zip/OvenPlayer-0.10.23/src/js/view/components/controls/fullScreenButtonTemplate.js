export default (uiText) => {
    return (
        `<button class="op-button op-fullscreen-button">`+
        `<i class="op-con op-fullscreen-expand"></i>` +
        `<i class="op-con op-fullscreen-compress"></i>` +
        `</button>`
    );
};
