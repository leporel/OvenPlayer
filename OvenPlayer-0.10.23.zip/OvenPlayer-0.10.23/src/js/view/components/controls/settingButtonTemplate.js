export default (uiText) => {
    return (`<button class="op-button op-setting-button"><i class="op-con op-setting"></i></button>`);
};