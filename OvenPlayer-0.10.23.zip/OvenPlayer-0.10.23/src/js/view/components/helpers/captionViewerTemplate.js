/**
 * Created by hoho on 22/11/2018.
 */
export default (uiText) => {
    return (
        `<div class="op-caption-viewer">` +
        `    <div class="op-caption-text-container">` +
        `        <pre class="op-caption-text"></pre>` +
        `      </div>` +
        `</div>`
    );
};