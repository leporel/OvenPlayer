/**
 * Created by hoho on 2018. 7. 19..
 */

const HelpersTemplate = function(uiText, text){
    return `<div class="op-helpers-container"></div>`;
};

export default HelpersTemplate;
