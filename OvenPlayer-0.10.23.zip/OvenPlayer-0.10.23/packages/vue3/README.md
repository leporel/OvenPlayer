# OvenPlayer-Vue3

Reusable OvenPlayer component for Vue.js