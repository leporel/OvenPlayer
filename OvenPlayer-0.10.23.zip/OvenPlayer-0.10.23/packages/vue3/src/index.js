import OvenPlayerVue3 from './OvenPlayer.vue';
export default OvenPlayerVue3;